import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import SplashScreen from "../Screens/SplashScreen";
import OnboardingScreen from "../Screens/OnboardingScreen";
import LanguageScreen from "../Screens/LanguageScreen";
import LoginScreen from "../Screens/Auth/LoginScreen";
import RegisterScreen from "../Screens/Auth/RegisterScreen";
import ForgotPasswordScreen from "../Screens/Auth/ForgotPassword";
import DrawerNavigation from "./DrawerNavigation";

import EditProfileScreen from "../Screens/Profile/EditProfile";
import TermsScreen from "../Screens/Profile/Terms";
import PrivacyScreen from "../Screens/Profile/Privacy";
import AboutScreen from "../Screens/Profile/About";
import ItemDetailsScreen from "../Screens/ItemDetails";
import OrderDetailsScreen from "../Screens/OrderDetails";
import OrderScreen from "../Screens/OrderScreen";
import BottomTabs from "./BottomTab";
import ChairsScreen from "../Screens/ChairsScreen";
const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  return (
    
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="Onboarding" component={OnboardingScreen} />
      <Stack.Screen name="Language" component={LanguageScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="RegisterScreen" component={RegisterScreen} />
      <Stack.Screen name="ForgotPasswordScreen" component={ForgotPasswordScreen} />
            <Stack.Screen name="Main" component={BottomTabs} />

      <Stack.Screen
name="MainApp"
component={DrawerNavigation}
/>
 <Stack.Screen
name="EditProfile"
component={EditProfileScreen}
/>
<Stack.Screen
name="TermsScreen"
component={TermsScreen}
/><Stack.Screen
name="PrivacyScreen"
component={PrivacyScreen}
/>
<Stack.Screen
name="AboutScreen"
component={AboutScreen}
/>
<Stack.Screen
name="ItemDetailsScreen"
component={ItemDetailsScreen}
/>
<Stack.Screen
name="OrderDetailsScreen"
component={OrderDetailsScreen}
/>
<Stack.Screen
name="OrderScreen"
component={OrderScreen}
/>
<Stack.Screen
name="ChairsScreen"
component={ChairsScreen}
/>
    </Stack.Navigator>
  );
}