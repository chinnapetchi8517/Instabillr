import React from "react";
import { 
View, 
Text, 
StyleSheet, 
TouchableOpacity,Image 
} from "react-native";

import { createDrawerNavigator, DrawerContentScrollView } from "@react-navigation/drawer";

import Ionicons from "react-native-vector-icons/Ionicons";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import Feather from "react-native-vector-icons/Feather";

import BottomTabs from "./BottomTab";
import SalesScreen from "../Screens/BottomTab/SalesScreen";
import OrdersScreen from "../Screens/BottomTab/OrdersScreen";
import colors from "../Utils/colors";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from "react-native-responsive-screen";
const Drawer = createDrawerNavigator();

function CustomDrawerContent({ navigation }) {

return (

<DrawerContentScrollView contentContainerStyle={{ flex:1 }}>

<View style={styles.container}>

{/* Header */}

<View style={styles.header}>
{/* <Ionicons name="restaurant" size={26} color={colors.primary} /> */}
 <Image
        source={require("../../assets/Images/applogo.png")}
        style={styles.logo}
      />
{/* <Text style={styles.headerTitle}>Instabillr</Text> */}

<TouchableOpacity>
<Ionicons name="close" size={24} color="#000"/>
</TouchableOpacity>

</View>

{/* Menu */}

<TouchableOpacity 
style={[styles.menuItem, styles.activeMenu]}
onPress={() => navigation.navigate("Home")}
>
<Feather name="home" size={20} color="#3A5A7A" />
<Text style={styles.menuText}>Home</Text>
<Ionicons name="chevron-forward" size={18} color="#888"/>
</TouchableOpacity>


<TouchableOpacity 
style={styles.menuItem}
onPress={() => navigation.navigate("Dashboard")}
>
<MaterialIcons name="dashboard" size={20} color="#22A45D" />
<Text style={styles.menuText}>Dashboard</Text>
<Ionicons name="chevron-forward" size={18} color="#888"/>
</TouchableOpacity>


<TouchableOpacity 
style={styles.menuItem}
onPress={() => navigation.navigate("Quotation")}
>
<MaterialIcons name="receipt-long" size={20} color="#2C9FBF" />
<Text style={styles.menuText}>Quotation List</Text>
<Ionicons name="chevron-forward" size={18} color="#888"/>
</TouchableOpacity>


<TouchableOpacity style={styles.menuItem}>
<Feather name="box" size={20} color="#9C4AE0" />
<Text style={styles.menuText}>Items</Text>
<Ionicons name="chevron-down" size={18} color="#888"/>
</TouchableOpacity>


<TouchableOpacity style={styles.menuItem}>
<Feather name="grid" size={20} color="#607D8B" />
<Text style={styles.menuText}>Table</Text>
<Ionicons name="chevron-forward" size={18} color="#888"/>
</TouchableOpacity>


</View>

<View style={styles.footer}>
<Text style={styles.version}>Version V-2.0.0</Text>
</View>

</DrawerContentScrollView>

);
}

export default function DrawerNavigation(){

return(

<Drawer.Navigator
screenOptions={{headerShown:false}}
drawerContent={(props)=> <CustomDrawerContent {...props} />}
>

<Drawer.Screen name="Home" component={BottomTabs} />
<Drawer.Screen name="Dashboard" component={SalesScreen} />
<Drawer.Screen name="Quotation" component={OrdersScreen} />

</Drawer.Navigator>

);

}

const styles = StyleSheet.create({

container:{
flex:1,
padding:10
},
logo:{
width:wp("90%"),
height:hp("20%"),
resizeMode:"contain",
alignSelf:"center",
//marginBottom:hp("2%")
},
header:{
flexDirection:"row",
alignItems:"center",
justifyContent:"center",
//marginBottom:5
},

headerTitle:{
fontSize:18,
fontWeight:"bold",
flex:1,
marginLeft:10
},

menuItem:{
flexDirection:"row",
alignItems:"center",
padding:14,
borderRadius:10,
marginBottom:8
},

activeMenu:{
backgroundColor:"#F2F4F7"
},

menuText:{
flex:1,
fontSize:16,
marginLeft:12
},

footer:{
padding:20
},

version:{
textAlign:"center",
color:"#888",
fontSize:15
}

});