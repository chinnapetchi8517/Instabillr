import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Image
} from "react-native";

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from "react-native-responsive-screen";

import Icon from "react-native-vector-icons/Ionicons";
import colors from "../../Utils/colors";

export default function RegisterScreen({ navigation }) {

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [errors, setErrors] = useState({});

  const validate = () => {

    let valid = true;
    let newErrors = {};

    if (!name) {
      newErrors.name = "Name is required";
      valid = false;
    }

    if (!email) {
      newErrors.email = "Email is required";
      valid = false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Invalid email";
      valid = false;
    }

    if (!password) {
      newErrors.password = "Password required";
      valid = false;
    } else if (password.length < 6) {
      newErrors.password = "Minimum 6 characters";
      valid = false;
    }

    if (confirmPassword !== password) {
      newErrors.confirmPassword = "Passwords do not match";
      valid = false;
    }

    setErrors(newErrors);

    return valid;
  };

  const handleRegister = () => {

    if (validate()) {
      console.log("Register Success");
    }

  };

  return (
    <View style={styles.container}>

      {/* Logo */}

      <Image
        source={require("../../../assets/Images/applogo.png")}
        style={styles.logo}
      />

      <Text style={styles.title}>Create An account</Text>
<Text style={styles.title1}>
         Please enter your details
        </Text>
      {/* Name */}

      <TextInput
        placeholder="Enter Name"
        placeholderTextColor="#888"
        style={styles.input}
        value={name}
        onChangeText={setName}
      />

      {errors.name && <Text style={styles.error}>{errors.name}</Text>}

      {/* Email */}

      <TextInput
        placeholder="Enter Email"
        placeholderTextColor="#888"
        style={styles.input}
        value={email}
        onChangeText={setEmail}
      />

      {errors.email && <Text style={styles.error}>{errors.email}</Text>}

      {/* Password */}

      <View style={styles.passwordContainer}>

        <TextInput
          placeholder="Enter Password"
          placeholderTextColor="#888"
          style={styles.passwordInput}
          secureTextEntry={!showPassword}
          value={password}
          onChangeText={setPassword}
        />

        <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
          <Icon
            name={showPassword ? "eye-off" : "eye"}
            size={wp("5%")}
            color="#666"
          />
        </TouchableOpacity>

      </View>

      {errors.password && <Text style={styles.error}>{errors.password}</Text>}

      {/* Confirm Password */}

      <View style={styles.passwordContainer}>

        <TextInput
          placeholder="Confirm Password"
          placeholderTextColor="#888"
          style={styles.passwordInput}
          secureTextEntry={!showConfirmPassword}
          value={confirmPassword}
          onChangeText={setConfirmPassword}
        />

        <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)}>
          <Icon
            name={showConfirmPassword ? "eye-off" : "eye"}
            size={wp("5%")}
            color="#666"
          />
        </TouchableOpacity>

      </View>

      {errors.confirmPassword && <Text style={styles.error}>{errors.confirmPassword}</Text>}

      {/* Register Button */}

      <TouchableOpacity style={styles.button} onPress={handleRegister}>
        <Text style={styles.buttonText}>Sign Up</Text>
      </TouchableOpacity>

      {/* Login Option */}

      <View style={styles.loginContainer}>

        <Text style={styles.loginText}>
          Already have an account?
        </Text>

        <TouchableOpacity onPress={() => navigation.navigate("Login")}>
          <Text style={styles.loginButton}> Login</Text>
        </TouchableOpacity>

      </View>

    </View>
  );
}

const styles = StyleSheet.create({

container:{
flex:1,
padding:wp("5%"),
backgroundColor:"#fff",
justifyContent:"center"
},

logo:{
width:wp("90%"),
height:hp("25%"),
resizeMode:"contain",
alignSelf:"center"
},

title:{
fontSize:wp("6.4%"),
fontWeight:"bold",
textAlign:"center",
marginBottom:hp("1%")
},
title1:{
fontSize:wp("4.2%"),
fontWeight:"500",
textAlign:"center",
color:'#888',
marginBottom:hp("4%")
},
input:{
borderWidth:1,
borderColor:"#aaa",
borderRadius:wp("2%"),
padding:hp("1.8%"),
color:"black",
fontSize:wp("4%"),
marginBottom:hp("2%")
},

passwordContainer:{
flexDirection:"row",
alignItems:"center",
borderWidth:1,
borderColor:"#aaa",
borderRadius:wp("2%"),
paddingHorizontal:wp("3%"),
marginBottom:hp("2%")
},

passwordInput:{
flex:1,
padding:hp("1.8%"),
color:"black",
fontSize:wp("4%")
},

error:{
color:"red",
fontSize:wp("3.8%"),
marginBottom:hp("1%")
},

button:{
backgroundColor:colors.primary,
padding:hp("2%"),
borderRadius:wp("2%"),
marginTop:hp("3%")
},

buttonText:{
color:"#fff",
textAlign:"center",
fontSize:wp("5%"),
fontWeight:"bold"
},

loginContainer:{
flexDirection:"row",
justifyContent:"center",
marginTop:hp("3%")
},

loginText:{
fontSize:wp("4%"),
color:"#444"
},

loginButton:{
fontSize:wp("4%"),
color:colors.primary,
fontWeight:"bold"
}

});