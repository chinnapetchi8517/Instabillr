

// import React, { useState, useMemo, useEffect } from "react";
// import { View, Text, FlatList, TouchableOpacity, Alert,StyleSheet,Modal, TextInput } from "react-native";
// import Icon from "react-native-vector-icons/Ionicons";
// import colors from "../Utils/colors";
// import fonts from "../Utils/fonts";
// import CustomDropdown from "../Components/Dropdown";
// import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
// import { ApiService } from "../Services/authService";
// import { useLoader } from "../Context/LoaderContext";

// export default function OrderScreen({ route, navigation }) {
//   const { tableId, tableName, chairs = [], cart: routeCart = [], orderType: routeOrderType } = route.params;

//   const [step, setStep] = useState(1);
//   const [orderType, setOrderType] = useState(null);
//   const [selectedChairs, setSelectedChairs] = useState([]);
//   const [cart, setCart] = useState([]);
//     const [orderId, setOrderId] = useState('');
// const [cancelModalVisible, setCancelModalVisible] = useState(false);
// const [cancelNotes, setCancelNotes] = useState("");
// const [orderReady, setOrderReady] = useState(false);
//   const { showLoader, hideLoader } = useLoader();
// let order_id;
//   const orderTypeData = [
//     { id: "1", name: "Family" },
//     { id: "2", name: "Separate" },
//   ];

//   // =========================
//   // 💡 Handle two scenarios
//   // =========================
//   // const [loading, setLoading] = useState(true);

// // useEffect(() => {
// //   const init = async () => {
// //     if (routeCart?.length > 0) {
// //       setCart(routeCart);
// //       setStep(2);

// //       if (routeOrderType) {
// //         setOrderType(
// //           orderTypeData.find(
// //             (o) => o.name.toLowerCase() === routeOrderType.toLowerCase()
// //           )
// //         );
// //       }

// //       if (route.params?.chairs?.length > 0) {
// //         setSelectedChairs(route.params.chairs);
// //       }
// //     } else if (tableId) {
// //       await fetchOrderList(tableId);
// //     }
// //     // setLoading(false); // ✅ Ready to render
// //   };

// //   init();
// // }, []);
// // if (loading) {
// //   return (
// //     <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
// //       <Text>Loading...</Text>
// //     </View>
// //   );
// // }

//  useEffect(() => {
//   if (routeCart?.length > 0) {
//     showLoader()
//     setCart(routeCart);
//     setStep(2);

//     if (routeOrderType) {
//       setOrderType(
//         orderTypeData.find(
//           (o) => o.name.toLowerCase() === routeOrderType.toLowerCase()
//         )
//       );
//     }

//     if (route.params?.chairs?.length > 0) {
//       setSelectedChairs(route.params.chairs);
//     }
//     hideLoader()
//   } else if (tableId) {
//     // ✅ Only call fetchOrderList if tableId exists and not already fetched
//     fetchOrderList(tableId);
//   }
//   // eslint-disable-next-line react-hooks/exhaustive-deps
// }, []); // <- empty dependency array

// // Normalized fetch order
// const fetchOrderList = async (tableId) => {
//   try {
//     showLoader()
//     const response = await ApiService.getOrderByTable(tableId);
//     let orders = response.data;
// console.log(response,'response111111111111');

//     // Handle API returning array
//     if (Array.isArray(orders) && orders.length > 0) {
//       const order = orders[0]; // pick first order, you can filter by status

//       const apiCart = order.items.map((i) => ({
//         id: i.product_id,
//         name: i.product_name,
//         qty: parseFloat(i.qty),
//         price: parseFloat(i.unit_price_inc_tax),
//         variation_id: i.variation_id,
//       }));
// console.log("order?.idorder?.id",order?.id);

//       setCart(apiCart);
//       setSelectedChairs([order.chair_no]);
//       order_id=order?.id;
//       setOrderId(order?.id)
//       setOrderType(
//         orderTypeData.find(
//           (o) => o.name.toLowerCase() === order.order_type.toLowerCase()
//         )
//       );
//       setStep(2);
//     }
//     hideLoader()
//   } catch (error) {
//     hideLoader()
//     console.log("Fetch order error:", error);
//     Alert.alert("Error", "Failed to fetch order");
//   }
// };


//   // =========================
//   // Add / Remove items, total, toggle chair (same as before)
//   // =========================
//   const toggleChair = (chairNo) => {
//     if (orderType?.name.toLowerCase() === "family") {
//       setSelectedChairs([chairNo]);
//     } else {
//       if (selectedChairs.includes(chairNo)) {
//         setSelectedChairs(selectedChairs.filter((c) => c !== chairNo));
//       } else {
//         setSelectedChairs([...selectedChairs, chairNo]);
//       }
//     }
//   };

//   const addItem = (item) => {
//     const exists = cart.find((i) => i.id === item.id);
//     if (exists) {
//       setCart(cart.map((i) => i.id === item.id ? { ...i, qty: i.qty + 1 } : i));
//     } else {
//       setCart([...cart, { ...item, qty: 1 }]);
//     }
//   };

//   const removeItem = (item) => {
//   const exists = cart.find((i) => String(i.id) === String(item.id));
//   if (!exists) return;

//   if (exists.qty === 1) {
//     setCart((prev) => prev.filter((i) => String(i.id) !== String(item.id)));
//   } else {
//     setCart((prev) =>
//       prev.map((i) =>
//         String(i.id) === String(item.id) ? { ...i, qty: i.qty - 1 } : i
//       )
//     );
//   }
// };

//   const total = useMemo(() => cart.reduce((sum, i) => sum + i.price * i.qty, 0), [cart]);

 
// const uniqueCart = cart.reduce((acc, item) => {
//   const existing = acc.find(i => String(i.id) === String(item.id));
//   if (existing) {
//     existing.qty += item.qty; // increment quantity
//   } else {
//     acc.push({ ...item }); // add new item
//   }
//   return acc;
// }, []);
// const handleCancel = () => {
//   setCancelNotes(""); // reset notes
//   setCancelModalVisible(true);
// };
// useEffect(() => {

//   if (orderId && cart.length >= 0) { // cart may be empty initially
//     setOrderReady(true);
//   } else {
//     setOrderReady(false);
//   }
// }, [orderId, cart]);
// const confirmCancel = async () => {
//   // console.log(orderReady,orderId,'orderIdorderIdorderId');
  
//   if (!orderId) {
//     Alert.alert("Error", "No order found to cancel");
//     return;
//   }

//   try {
//     const res = await ApiService.cancelOrder(orderId, { cancel_note: cancelNotes });
//     console.log(res,'res');
    
//     if (res.status) {
//       Alert.alert("Success", "Order canceled successfully");
//       setCart([]);
//       setStep(1);
//     } else {
//       Alert.alert("Error", res.message || "Failed to cancel order");
//     }
//   } catch (error) {
//     console.log("Cancel order error:", error);
//     Alert.alert("Error", "Failed to cancel order");
//   }
// };
// const handleBill = async () => {
//   if (!orderId) {
//     Alert.alert("Error", "No order found to generate bill");
//     return;
//   }

//   try {
//     const res = await ApiService.generateBill(orderId);
//     if (res.status) { 
//       Alert.alert(res.message)
//       // adjust based on your API response
//       // Navigate to BillingScreen and pass bill details
//       // navigation.navigate("Main", { screen:'POS',{params}
//       //   tableId,
//       //   tableName,
//       //   selectedChairs,
//       //   cart,
//       //   total,
//       //   billData: res.data, // pass generated bill
//       // });
//     } else {
//       Alert.alert("Error", res.message || "Failed to generate bill");
//     }
//   } catch (error) {
//     console.log("Generate bill error:", error);
//     Alert.alert("Error", "Failed to generate bill");
//   }
// };
//   // =========================
//   // STEP 1: Chair / OrderType selection
//   // =========================
//   if (step === 1) {
//     return (
//       <View style={{ flex: 1, padding: wp("4%"), backgroundColor: "#f8f9fb" }}>
//         <Text style={{ fontSize: wp("5%"), fontFamily: fonts.bold, marginBottom: hp("2%") }}>{tableName}</Text>

//         <CustomDropdown
//           label="Select Order Type"
//           data={orderTypeData}
//           selected={orderType}
//           onSelect={setOrderType}
//         />

//         <FlatList
//           data={chairs}
//           numColumns={3}
//            keyExtractor={(item, index) => index.toString()}
//           // keyExtractor={(item) => item.chair_no.toString()}
//           renderItem={({ item }) => {
//             const selected = selectedChairs.includes(item.chair_no);
//             return (
//               <TouchableOpacity
//                 style={{
//                   width: wp("25%"),
//                   margin: wp("2%"),
//                   marginTop: hp("3%"),
//                   padding: wp("4%"),
//                   borderRadius: 12,
//                   borderWidth: 1,
//                   borderColor: "#ddd",
//                   alignItems: "center",
//                   backgroundColor: selected ? "#d4edda" : "#fff",
//                   opacity: item.status !== "available" ? 0.5 : 1
//                 }}
//                 disabled={item.status !== "available"}
//                 onPress={() => toggleChair(item.chair_no)}
//               >
//                 <Text style={{ fontFamily: fonts.medium }}>Chair {item.chair_no}</Text>
//               </TouchableOpacity>
//             );
//           }}
//         />

//         <TouchableOpacity
//           style={{ backgroundColor: colors.primary, padding: wp("4%"), borderRadius: 10, marginTop: hp("2%"), alignItems: "center" }}
//           onPress={() => {
//             if (selectedChairs.length === 0) { Alert.alert("Select Chair"); return; }
//             setStep(2);
//           }}
//         >
//           <Text style={{ color: "#fff", fontFamily: fonts.bold }}>Continue</Text>
//         </TouchableOpacity>
//       </View>
//     );
//   }

//   // =========================
//   // STEP 2: Order Items
//   // =========================
//   return (
//     <View style={{ flex: 1, padding: wp("0%"), backgroundColor: "#f8f9fb" }}>
//       <View style={{ backgroundColor: colors.primary, padding: wp("5%"),marginTop:15,marginHorizontal:20, borderRadius: 10 }}>
//         <Text style={{ color: "#fff", fontFamily: fonts.bold }}>{tableName} (Chair {selectedChairs.join(", ")})</Text>
//         <Text style={{ color: "#fff", fontSize: wp("3.5%"), marginTop: 4 }}>Type: {orderType?.name}</Text>
//       </View>

//       {cart?.length === 0 ? (
//         <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
//           <Text style={{ color: "#999", fontSize: wp("4%"), fontFamily: fonts.medium }}>No items added yet</Text>
//         </View>
//       ) : (
//         <FlatList
//         keyExtractor={(item, index) => (item.id ? item.id.toString() : index.toString())}
//           data={uniqueCart}
//           // keyExtractor={(item) => item.id.toString()}
//           renderItem={({ item }) => (
//             <View style={{ backgroundColor: "#fff", margin: wp("2%"), padding: wp("4%"), borderRadius: 10, flexDirection: "row", justifyContent: "space-between" }}>
//               <View>
//                 <Text style={{ fontFamily: fonts.medium }}>{item.name}</Text>
//                 <Text style={{ color: "#777" }}>₹{item.price} x {item.qty}</Text>
//               </View>

//               <View style={{ flexDirection: "row", alignItems: "center" }}>
//                 {/* <TouchableOpacity style={{ backgroundColor: colors.primary, padding: wp("2%"), borderRadius: 6 }} onPress={() => removeItem(item)}>
//                   <Icon name="remove" color="#fff" size={16} />
//                 </TouchableOpacity> */}

//                 <Text style={{ marginHorizontal: wp("3%"), fontFamily: fonts.bold }}>{item.qty}</Text>

//                 {/* <TouchableOpacity style={{ backgroundColor: colors.primary, padding: wp("2%"), borderRadius: 6 }} onPress={() => addItem(item)}>
//                   <Icon name="add" color="#fff" size={16} />
//                 </TouchableOpacity> */}
//               </View>
//             </View>
//           )}
//           contentContainerStyle={{ paddingBottom: hp("20%"),marginHorizontal:12 ,marginTop:5}}
//         />
//       )}
//       {console.log(selectedChairs,"selectedChairs")
//       }
//        <TouchableOpacity
//       // style={styles.addBtn}
//         style={[styles.addBtn, (!orderId && cart.length > 0) && { opacity: 0. }]}

//       onPress={() => {
//          navigation.navigate("Main", {
//         screen: "Items",
//         params: {
//           tableId,
//           tableName,
//           chairs: selectedChairs,
//           orderType: orderType?.name || "family",
//           onSelectProduct: (items) => setCart(items),
//           isadditems:cart.length === 0?false:true,
//           orderId,
//         },
//       });
//         // navigation.navigate("Items", {
//         //   tableId,
//         //   tableName,
//         //   chairs: selectedChairs,
//         //   orderType: orderType?.name || "family",
//         //   onSelectProduct: (items) => setCart(items),
//         // });
//       }}
//     >
//       <Icon name="add" size={20} color="#fff" />
//       <Text style={styles.addText}>
//         {cart.length === 0 ? "Create Order" : "Add Items"}
//       </Text>
//     </TouchableOpacity>

//     {/* FOOTER BUTTONS */}
//     {cart.length > 0 && (
//       <View style={styles.footer}>
//         <View>
//           <Text>Total</Text>
//           <Text style={styles.total}>₹{total}</Text>
//         </View>

//         <View style={{ flexDirection: "row" }}>
//           <TouchableOpacity onPress={()=>handleCancel()}  style={styles.cancelBtn} onPress={handleCancel}>
//             <Text style={styles.btnText}>Cancel</Text>
//           </TouchableOpacity>

//           <TouchableOpacity onPress={()=>handleBill()} style={styles.billBtn} onPress={handleBill}>
//             <Text style={styles.btnText}> Move to Bill</Text>
//           </TouchableOpacity>
//         </View>
//       </View>
//     )}
   
// <Modal
//   visible={cancelModalVisible}
//   transparent
//   animationType="fade"
//   onRequestClose={() => setCancelModalVisible(false)}
// >
//   <View style={{
//     flex:1,
//     justifyContent:'center',
//     alignItems:'center',
//     backgroundColor:'rgba(0,0,0,0.5)'
//   }}>
//     <View style={{
//       width: wp('80%'),
//       backgroundColor:'#fff',
//       borderRadius:10,
//       padding: wp('5%')
//     }}>
//       <Text style={{ fontFamily: fonts.bold, fontSize: wp('4%'), marginBottom: hp('2%') }}>
//         Cancel Order
//       </Text>
//       <TextInput
//         placeholder="Add cancellation notes (optional)"
//         style={{
//           borderWidth:1,
//           borderColor:'#ccc',
//           borderRadius:8,
//           padding: wp('3%'),
//           height: hp('15%'),
//           textAlignVertical:'top',
//           marginBottom: hp('2%')
//         }}
//         multiline
//         value={cancelNotes}
//         onChangeText={setCancelNotes}
//       />
//       <View style={{ flexDirection:'row', justifyContent:'flex-end' }}>
//         <TouchableOpacity
//           onPress={() => setCancelModalVisible(false)}
//           style={{ marginRight: wp('3%') }}
//         >
//           <Text style={{ color:'#999' }}>Cancel</Text>
//         </TouchableOpacity>
//         <TouchableOpacity
//           onPress={async () => {
//             setCancelModalVisible(false);
//             await confirmCancel(); // call API
//           }}
//         >
//           <Text style={{ color:colors.primary, fontWeight:'bold' }}>Submit</Text>
//         </TouchableOpacity>
//       </View>
//     </View>
//   </View>
// </Modal>
//     </View>
//   );
// }





import React, { useState, useMemo, useEffect } from "react";
import { View, Text, FlatList, TouchableOpacity, Alert,StyleSheet,Modal, TextInput } from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import colors from "../Utils/colors";
import fonts from "../Utils/fonts";
import CustomDropdown from "../Components/Dropdown";
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { ApiService } from "../Services/authService";
import { useLoader } from "../Context/LoaderContext";

export default function OrderScreen({ route, navigation }) {
  const { tableId, tableName, chairs = [], cart: routeCart = [], orderType: routeOrderType } = route.params;

  const [step, setStep] = useState(1);
  const [orderType, setOrderType] = useState(null);
  const [selectedChairs, setSelectedChairs] = useState([]);
  const [cart, setCart] = useState([]);
    const [orderId, setOrderId] = useState('');
const [cancelModalVisible, setCancelModalVisible] = useState(false);
const [cancelNotes, setCancelNotes] = useState("");
const [orderReady, setOrderReady] = useState(false);
  const { showLoader, hideLoader } = useLoader();
let order_id;
  const orderTypeData = [
    { id: "1", name: "Family" },
    { id: "2", name: "Separate" },
  ];

  // =========================
  // 💡 Handle two scenarios
  // =========================
  // const [loading, setLoading] = useState(true);

// useEffect(() => {
//   const init = async () => {
//     if (routeCart?.length > 0) {
//       setCart(routeCart);
//       setStep(2);

//       if (routeOrderType) {
//         setOrderType(
//           orderTypeData.find(
//             (o) => o.name.toLowerCase() === routeOrderType.toLowerCase()
//           )
//         );
//       }

//       if (route.params?.chairs?.length > 0) {
//         setSelectedChairs(route.params.chairs);
//       }
//     } else if (tableId) {
//       await fetchOrderList(tableId);
//     }
//     // setLoading(false); // ✅ Ready to render
//   };

//   init();
// }, []);
// if (loading) {
//   return (
//     <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
//       <Text>Loading...</Text>
//     </View>
//   );
// }

 useEffect(() => {
  if (routeCart?.length > 0) {
    showLoader()
    setCart(routeCart);
    //setStep(2);

    if (routeOrderType) {
      setOrderType(
        orderTypeData.find(
          (o) => o.name.toLowerCase() === routeOrderType.toLowerCase()
        )
      );
    }

    if (route.params?.chairs?.length > 0) {
      setSelectedChairs(route.params.chairs);
    }
    hideLoader()
  } else if (tableId) {
    // ✅ Only call fetchOrderList if tableId exists and not already fetched
    fetchOrderList(tableId);
  }
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []); // <- empty dependency array

// Normalized fetch order
const fetchOrderList = async (tableId) => {
  try {
    showLoader()
    const response = await ApiService.getOrderByTable(tableId);
    let orders = response.data;
console.log(response,'response111111111111');

    // Handle API returning array
    if (Array.isArray(orders) && orders.length > 0) {
      const order = orders[0]; // pick first order, you can filter by status

      const apiCart = order.items.map((i) => ({
        id: i.product_id,
        name: i.product_name,
        qty: parseFloat(i.qty),
        price: parseFloat(i.unit_price_inc_tax),
        variation_id: i.variation_id,
      }));
console.log("order?.idorder?.id",order?.id);

      setCart(apiCart);
      setSelectedChairs([order.chair_no]);
      order_id=order?.id;
      setOrderId(order?.id)
      setOrderType(
        orderTypeData.find(
          (o) => o.name.toLowerCase() === order.order_type.toLowerCase()
        )
      );
      setStep(2);
    }
    hideLoader()
  } catch (error) {
    hideLoader()
    console.log("Fetch order error:", error);
    Alert.alert("Error", "Failed to fetch order");
  }
};


  // =========================
  // Add / Remove items, total, toggle chair (same as before)
  // =========================
  const toggleChair = (chairNo) => {
    if (orderType?.name.toLowerCase() === "family") {
      setSelectedChairs([chairNo]);
    } else {
      if (selectedChairs.includes(chairNo)) {
        setSelectedChairs(selectedChairs.filter((c) => c !== chairNo));
      } else {
        setSelectedChairs([...selectedChairs, chairNo]);
      }
    }
  };

  const addItem = (item) => {
    const exists = cart.find((i) => i.id === item.id);
    if (exists) {
      setCart(cart.map((i) => i.id === item.id ? { ...i, qty: i.qty + 1 } : i));
    } else {
      setCart([...cart, { ...item, qty: 1 }]);
    }
  };

  const removeItem = (item) => {
  const exists = cart.find((i) => String(i.id) === String(item.id));
  if (!exists) return;

  if (exists.qty === 1) {
    setCart((prev) => prev.filter((i) => String(i.id) !== String(item.id)));
  } else {
    setCart((prev) =>
      prev.map((i) =>
        String(i.id) === String(item.id) ? { ...i, qty: i.qty - 1 } : i
      )
    );
  }
};

  const total = useMemo(() => cart.reduce((sum, i) => sum + i.price * i.qty, 0), [cart]);

 
const uniqueCart = cart.reduce((acc, item) => {
  const existing = acc.find(i => String(i.id) === String(item.id));
  if (existing) {
    existing.qty += item.qty; // increment quantity
  } else {
    acc.push({ ...item }); // add new item
  }
  return acc;
}, []);
const handleCancel = () => {
  setCancelNotes(""); // reset notes
  setCancelModalVisible(true);
};
useEffect(() => {

  if (orderId && cart.length >= 0) { // cart may be empty initially
    setOrderReady(true);
  } else {
    setOrderReady(false);
  }
}, [orderId, cart]);
const confirmCancel = async () => {
  // console.log(orderReady,orderId,'orderIdorderIdorderId');
  
  if (!orderId) {
    Alert.alert("Error", "No order found to cancel");
    return;
  }

  try {
    const res = await ApiService.cancelOrder(orderId, { cancel_note: cancelNotes });
    console.log(res,'res');
    
    if (res.status) {
      Alert.alert("Success", "Order canceled successfully");
      setCart([]);
      setStep(1);
    } else {
      Alert.alert("Error", res.message || "Failed to cancel order");
    }
  } catch (error) {
    console.log("Cancel order error:", error);
    Alert.alert("Error", "Failed to cancel order");
  }
};
const handleBill = async () => {
  if (!orderId) {
    Alert.alert("Error", "No order found to generate bill");
    return;
  }

  try {
    const res = await ApiService.generateBill(orderId);
    if (res.status) { 
      Alert.alert(res.message)
      // adjust based on your API response
      // Navigate to BillingScreen and pass bill details
      // navigation.navigate("Main", { screen:'POS',{params}
      //   tableId,
      //   tableName,
      //   selectedChairs,
      //   cart,
      //   total,
      //   billData: res.data, // pass generated bill
      // });
    } else {
      Alert.alert("Error", res.message || "Failed to generate bill");
    }
  } catch (error) {
    console.log("Generate bill error:", error);
    Alert.alert("Error", "Failed to generate bill");
  }
};
  // =========================
  // STEP 1: Chair / OrderType selection
  // =========================
  if (step === 1) {
    return (
      <View style={{ flex: 1, padding: wp("4%"), backgroundColor: "#f8f9fb" }}>
        <Text style={{ fontSize: wp("5%"), fontFamily: fonts.bold, marginBottom: hp("2%") }}>{tableName}</Text>

        <CustomDropdown
          label="Select Order Type"
          data={orderTypeData}
          selected={orderType}
          onSelect={setOrderType}
        />

        <FlatList
          data={chairs}
          numColumns={3}
           keyExtractor={(item, index) => index.toString()}
          // keyExtractor={(item) => item.chair_no.toString()}
          renderItem={({ item }) => {
            const selected = selectedChairs.includes(item.chair_no);
            return (
              <TouchableOpacity
                style={{
                  width: wp("25%"),
                  margin: wp("2%"),
                  marginTop: hp("3%"),
                  padding: wp("4%"),
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: "#ddd",
                  alignItems: "center",
                  backgroundColor: selected ? "#d4edda" : "#fff",
                  opacity: item.status !== "available" ? 0.5 : 1
                }}
                disabled={item.status !== "available"}
                onPress={() => toggleChair(item.chair_no)}
              >
                <Text style={{ fontFamily: fonts.medium }}>Chair {item.chair_no}</Text>
              </TouchableOpacity>
            );
          }}
        />

        <TouchableOpacity
          style={{ backgroundColor: colors.primary, padding: wp("4%"), borderRadius: 10, marginTop: hp("2%"), alignItems: "center" }}
          onPress={() => {
            if (selectedChairs.length === 0) { Alert.alert("Select Chair"); return; }
            setStep(2);
          }}
        >
          <Text style={{ color: "#fff", fontFamily: fonts.bold }}>Continue</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // =========================
  // STEP 2: Order Items
  // =========================
  return (
    <View style={{ flex: 1, padding: wp("0%"), backgroundColor: "#f8f9fb" }}>
      <View style={{ backgroundColor: colors.primary, padding: wp("5%"),marginTop:15,marginHorizontal:20, borderRadius: 10 }}>
        <Text style={{ color: "#fff", fontFamily: fonts.bold }}>{tableName} (Chair {selectedChairs.join(", ")})</Text>
        <Text style={{ color: "#fff", fontSize: wp("3.5%"), marginTop: 4 }}>Type: {orderType?.name}</Text>
      </View>

      {cart?.length === 0 ? (
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <Text style={{ color: "#999", fontSize: wp("4%"), fontFamily: fonts.medium }}>No items added yet</Text>
        </View>
      ) : (
        <FlatList
        keyExtractor={(item, index) => (item.id ? item.id.toString() : index.toString())}
          data={uniqueCart}
          // keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={{ backgroundColor: "#fff", margin: wp("2%"), padding: wp("4%"), borderRadius: 10, flexDirection: "row", justifyContent: "space-between" }}>
              <View>
                <Text style={{ fontFamily: fonts.medium }}>{item.name}</Text>
                <Text style={{ color: "#777" }}>₹{item.price} x {item.qty}</Text>
              </View>

              <View style={{ flexDirection: "row", alignItems: "center" }}>
                {/* <TouchableOpacity style={{ backgroundColor: colors.primary, padding: wp("2%"), borderRadius: 6 }} onPress={() => removeItem(item)}>
                  <Icon name="remove" color="#fff" size={16} />
                </TouchableOpacity> */}

                <Text style={{ marginHorizontal: wp("3%"), fontFamily: fonts.bold }}>{item.qty}</Text>

                {/* <TouchableOpacity style={{ backgroundColor: colors.primary, padding: wp("2%"), borderRadius: 6 }} onPress={() => addItem(item)}>
                  <Icon name="add" color="#fff" size={16} />
                </TouchableOpacity> */}
              </View>
            </View>
          )}
          contentContainerStyle={{ paddingBottom: hp("20%"),marginHorizontal:12 ,marginTop:5}}
        />
      )}
      {console.log(selectedChairs,"selectedChairs")
      }
       <TouchableOpacity
      // style={styles.addBtn}
        style={[styles.addBtn, (!orderId && cart.length > 0) && { opacity: 0. }]}

      onPress={() => {
         navigation.navigate("Main", {
        screen: "Items",
        params: {
          tableId,
          tableName,
          chairs: selectedChairs,
          orderType: orderType?.name || "family",
          onSelectProduct: (items) => setCart(items),
          isadditems:cart.length === 0?false:true,
          orderId,
        },
      });
        // navigation.navigate("Items", {
        //   tableId,
        //   tableName,
        //   chairs: selectedChairs,
        //   orderType: orderType?.name || "family",
        //   onSelectProduct: (items) => setCart(items),
        // });
      }}
    >
      <Icon name="add" size={20} color="#fff" />
      <Text style={styles.addText}>
        {cart.length === 0 ? "Create Order" : "Add Items"}
      </Text>
    </TouchableOpacity>

    {/* FOOTER BUTTONS */}
    {cart.length > 0 && (
      <View style={styles.footer}>
        <View>
          <Text>Total</Text>
          <Text style={styles.total}>₹{total}</Text>
        </View>

        <View style={{ flexDirection: "row" }}>
          <TouchableOpacity onPress={()=>handleCancel()}  style={styles.cancelBtn} onPress={handleCancel}>
            <Text style={styles.btnText}>Cancel</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={()=>handleBill()} style={styles.billBtn} onPress={handleBill}>
            <Text style={styles.btnText}> Move to Bill</Text>
          </TouchableOpacity>
        </View>
      </View>
    )}
   
<Modal
  visible={cancelModalVisible}
  transparent
  animationType="fade"
  onRequestClose={() => setCancelModalVisible(false)}
>
  <View style={{
    flex:1,
    justifyContent:'center',
    alignItems:'center',
    backgroundColor:'rgba(0,0,0,0.5)'
  }}>
    <View style={{
      width: wp('80%'),
      backgroundColor:'#fff',
      borderRadius:10,
      padding: wp('5%')
    }}>
      <Text style={{ fontFamily: fonts.bold, fontSize: wp('4%'), marginBottom: hp('2%') }}>
        Cancel Order
      </Text>
      <TextInput
        placeholder="Add cancellation notes (optional)"
        style={{
          borderWidth:1,
          borderColor:'#ccc',
          borderRadius:8,
          padding: wp('3%'),
          height: hp('15%'),
          textAlignVertical:'top',
          marginBottom: hp('2%')
        }}
        multiline
        value={cancelNotes}
        onChangeText={setCancelNotes}
      />
      <View style={{ flexDirection:'row', justifyContent:'flex-end' }}>
        <TouchableOpacity
          onPress={() => setCancelModalVisible(false)}
          style={{ marginRight: wp('3%') }}
        >
          <Text style={{ color:'#999' }}>Cancel</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={async () => {
            setCancelModalVisible(false);
            await confirmCancel(); // call API
          }}
        >
          <Text style={{ color:colors.primary, fontWeight:'bold' }}>Submit</Text>
        </TouchableOpacity>
      </View>
    </View>
  </View>
</Modal>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: wp("4%"),
    backgroundColor: "#f8f9fb",
  },

  title: {
    fontSize: wp("5%"),
    fontFamily: fonts.bold,
    marginBottom: hp("2%"),
  },

  chairCard: {
    width:wp('25%'),
    margin: wp("2%"),
    marginTop:hp('3%'),
    padding: wp("4%"),
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#ddd",
    alignItems: "center",
  },

  selectedChair: {
    backgroundColor: "#d4edda",
    borderColor: "#4CAF50",
  },

  disabledChair: {
    backgroundColor: "#eee",
  },

  chairText: {
    fontFamily: fonts.medium,
  },

  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginTop: 6,
  },

  continueBtn: {
    backgroundColor: colors.primary,
    padding: wp("4%"),
    borderRadius: 10,
    marginTop: hp("2%"),
    alignItems: "center",
  },

  header: {
    backgroundColor: colors.primary,
    padding: wp("4%"),
    borderRadius: 10,
  },

  headerText: {
    color: "#fff",
    fontFamily: fonts.bold,
  },

  itemCard: {
    backgroundColor: "#fff",
    margin: wp("2%"),
    padding: wp("4%"),
    borderRadius: 10,
    flexDirection: "row",
    justifyContent: "space-between",
  },

  itemName: {
    fontFamily: fonts.medium,
  },

  price: {
    color: "#777",
  },

  qtyContainer: {
    flexDirection: "row",
    alignItems: "center",
  },

  qtyBtn: {
    backgroundColor: colors.primary,
    padding: wp("2%"),
    borderRadius: 6,
  },

  qtyText: {
    marginHorizontal: wp("3%"),
    fontFamily: fonts.bold,
  },

  footer: {
    position: "absolute",
    bottom: 0,
    right:0,
    //left:0,
    width: "100%",
    backgroundColor: "#fff",
    padding: wp("4%"),
    flexDirection: "row",
    justifyContent: "space-between",
  },

  total: {
    fontSize: wp("5%"),
    fontFamily: fonts.bold,
  },

  cancelBtn: {
    backgroundColor: "#999",
    padding: wp("3%"),
    borderRadius: 8,
    marginRight: wp("2%"),
    alignItems:'center',
    justifyContent:'center'
  },

  billBtn: {
    backgroundColor: colors.primary,
    paddingHorizontal: wp("10%"),
    borderRadius: 8,
    alignItems:'center',
    justifyContent:'center'
  },

  btnText: {
    color: "#fff",
    textAlign:'center',
    fontFamily:fonts.bold
  },
  emptyBox: {
  flex: 1,
  justifyContent: "center",
  alignItems: "center",
},

emptyText: {
  color: "#999",
  fontSize: wp("4%"),
  fontFamily: fonts.medium,
},

subText: {
  color: "#fff",
  marginTop: 4,
  fontSize: wp("3.5%"),
},

addBtn: {
  position: "absolute",
  bottom: hp("12%"),
  right: wp("5%"),
  backgroundColor: colors.primary,
  flexDirection: "row",
  padding: wp("3%"),
  borderRadius: 30,
  alignItems: "center",
  elevation: 5,
},

addText: {
  color: "#fff",
  marginLeft: 5,
  fontFamily: fonts.medium,
},
});