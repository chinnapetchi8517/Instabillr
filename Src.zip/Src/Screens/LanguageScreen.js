import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity
} from "react-native";
import colors from "../Utils/colors";

const languages = [
  "Afrikaans",
  "Arabic",
  "Bangla",
  "Bulgarian",
  "Chinese",
  "Croatian",
  "Czech",
  "Danish",
  "English"
];

export default function LanguageScreen({ navigation }) {

  const [selected, setSelected] = useState(null);

  return (
    <View style={styles.container}>

      <Text style={styles.title}>
        Select Language
      </Text>

      <FlatList
        data={languages}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => setSelected(item)}
          >
            <Text style={styles.text}>{item}</Text>

            <View
              style={[
                styles.radio,
                selected === item && styles.selected
              ]}
            />
          </TouchableOpacity>
        )}
      />

      <TouchableOpacity
        style={styles.saveButton}
        onPress={() => navigation.navigate("Login")}
      >
        <Text style={styles.saveText}>Save</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20
  },

  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 20
  },

  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderColor: "#eee"
  },

  text: {
    fontSize: 16
  },

  radio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: colors.primary
  },

  selected: {
    backgroundColor: colors.primary
  },

  saveButton: {
    backgroundColor: colors.primary,
    padding: 15,
    borderRadius: 8,
    marginTop: 20
  },

  saveText: {
    textAlign: "center",
    color: "#fff",
    fontSize: 18
  }
});