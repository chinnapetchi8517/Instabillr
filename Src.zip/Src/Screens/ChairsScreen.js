import React from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from "react-native";

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

const STATUS_COLORS = {
  available: "#4CAF50",
  occupied: "#F44336",
};

export default function ChairsScreen({ route, navigation }) {
  const { tableId, tableName, chairs } = route.params;

  const handleChairPress = (chair) => {
    navigation.navigate("OrderScreen", {
      tableId,
      chairNo: chair.chair_no,
      tableName,
    });
  };

  const renderChair = ({ item }) => {
    return (
      <TouchableOpacity
        style={[
          styles.card,
          {
            backgroundColor:
              item.status === "available"
                ? STATUS_COLORS.available
                : STATUS_COLORS.occupied,
          },
        ]}
        onPress={() => handleChairPress(item)}
      >
        <Text style={styles.text}>Chair {item.chair_no}</Text>
        <Text style={styles.sub}>{item.status}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{tableName}</Text>

      <FlatList
        data={chairs}
        keyExtractor={(item) => item.chair_no.toString()}
        renderItem={renderChair}
        numColumns={3}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: wp("4%"),
  },

  title: {
    fontSize: wp("5%"),
    fontWeight: "bold",
    marginBottom: hp("2%"),
  },

  card: {
    flex: 1,
    margin: wp("2%"),
    height: hp("12%"),
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },

  text: {
    color: "#fff",
    fontSize: wp("4%"),
    fontWeight: "bold",
  },

  sub: {
    color: "#fff",
    fontSize: wp("3%"),
    marginTop: 4,
  },
});