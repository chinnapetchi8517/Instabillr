import React from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Icon from "react-native-vector-icons/MaterialIcons";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import Fonts from "../Utils/fonts";
import colors from "../Utils/colors";
import fonts from "../Utils/fonts";


const OrderDetailsScreen = ({ navigation, route }) => {
  const { item } = route.params;

  // sample items
  const orderItems = [
    { id: "1", name: "Fried Rice", qty: 2, price: 120 },
    { id: "2", name: "Chicken Curry", qty: 1, price: 180 },
    { id: "3", name: "Juice", qty: 2, price: 60 },
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case "Served":
        return "#27AE60";
      case "Preparing":
        return "#3498DB";
      case "Pending":
        return "#F39C12";
      default:
        return "#999";
    }
  };

  const renderItem = ({ item }) => (
    <View style={styles.itemRow}>
      <View style={{ flex: 1 }}>
        <Text style={styles.itemName}>{item.name}</Text>
        <Text style={styles.qty}>Qty: {item.qty}</Text>
      </View>
      <Text style={styles.price}>₹{item.price}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* HEADER */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Icon name="arrow-back" size={wp("6%")} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Order Details</Text>
      </View>

      {/* ORDER INFO */}
      <View style={styles.card}>
        <View style={styles.rowBetween}>
          <Text style={styles.orderId}>{item.id}</Text>

          <View
            style={[
              styles.statusBadge,
              { backgroundColor: getStatusColor(item.status) },
            ]}
          >
            <Text style={styles.statusText}>{item.status}</Text>
          </View>
        </View>

        <Text style={styles.text}>Table: {item.table}</Text>
        <Text style={styles.text}>Type: {item.type}</Text>
        <Text style={styles.text}>Customer: {item.customer}</Text>
      </View>

      {/* ITEMS */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Items</Text>

        <FlatList
          data={orderItems}
          keyExtractor={(i) => i.id}
          renderItem={renderItem}
        />

        <View style={styles.divider} />

        {/* TOTAL */}
        <View style={styles.totalRow}>
          <Text style={styles.totalText}>Total</Text>
          <Text style={styles.totalAmount}>₹{item.amount}</Text>
        </View>
      </View>

      {/* ACTION BUTTONS */}
      <View style={styles.actionContainer}>
        {item.status === "Pending" && (
          <TouchableOpacity style={styles.acceptBtn}>
            <Text style={styles.btnText}>Accept</Text>
          </TouchableOpacity>
        )}

        {item.status === "Preparing" && (
          <TouchableOpacity style={styles.serveBtn}>
            <Text style={styles.btnText}>Serve</Text>
          </TouchableOpacity>
        )}

        {item.status === "Served" && (
          <TouchableOpacity style={styles.completeBtn}>
            <Text style={styles.btnText}>Complete</Text>
          </TouchableOpacity>
        )}
      </View>
    </SafeAreaView>
  );
};

export default OrderDetailsScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F5F5",
  },

  header: {
    backgroundColor: colors.primary,
    flexDirection: "row",
    alignItems: "center",
    padding: wp("4%"),
  },

  headerTitle: {
    color: "#fff",
    fontSize: wp("5%"),
    marginLeft: wp("4%"),
    fontFamily: Fonts.semiBold,
  },

  card: {
    backgroundColor: "#fff",
    margin: wp("4%"),
    padding: wp("4%"),
    borderRadius: 12,
    elevation: 2,
  },

  rowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  orderId: {
    fontSize: wp("4.5%"),
    fontFamily: Fonts.bold,
  },

  text: {
    marginTop: 5,
    color: "#555",
    fontFamily: Fonts.medium,
  },

  sectionTitle: {
    fontSize: wp("4%"),
    fontFamily: Fonts.semiBold,
    marginBottom: 10,
  },

  itemRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
  },

  itemName: {
    fontSize: wp("3.8%"),
    fontFamily: Fonts.medium,
  },

  qty: {
    fontSize: wp("3.2%"),
    color: "#777",
  },

  price: {
    fontSize: wp("3.8%"),
    fontFamily: Fonts.medium,
  },

  divider: {
    height: 1,
    backgroundColor: "#eee",
    marginVertical: 10,
  },

  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  totalText: {
    fontSize: wp("4%"),
    fontFamily: Fonts.bold,
  },

  totalAmount: {
    fontSize: wp("4%"),
    fontFamily: Fonts.bold,
    color: colors.primary,
  },

  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },

  statusText: {
    color: "#fff",
    fontSize: wp("3%"),
    fontFamily:Fonts.medium,
  },

  actionContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: hp("2%"),
  },

  acceptBtn: {
    backgroundColor: "#3498DB",
    padding: 12,
    borderRadius: 8,
    width: "40%",
    alignItems: "center",
  },

  serveBtn: {
    backgroundColor: "#27AE60",
    padding: 12,
    borderRadius: 8,
    width: "40%",
    alignItems: "center",
  },

  completeBtn: {
    backgroundColor: "#8E44AD",
    padding: 12,
    borderRadius: 8,
    width: "60%",
    alignItems: "center",
  },

  btnText: {
    color: "#fff",
    fontFamily: Fonts.semiBold,
  },
});