import React from 'react';
import InfoScreen from '../../Components/InfoScreen';
export default function AboutScreen({ navigation }) {
  const content = `
Welcome to our app!

We are committed to providing the best experience for our users through simple, fast, and reliable services.

Our goal is to make your daily tasks easier and more efficient.

We continuously improve our app by adding new features and fixing issues based on your feedback.

Thank you for using our application ❤️
`;

  return (
    <InfoScreen
      title="About Us"
      content={content}
      navigation={navigation}
    />
  );
}