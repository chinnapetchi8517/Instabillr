import React from 'react';
import InfoScreen from '../../Components/InfoScreen';

export default function PrivacyScreen({ navigation }) {
  const content = `
Your privacy is important to us.

We do not collect personally identifiable information unless you voluntarily provide it.

We may use third-party services such as analytics tools that collect anonymous usage data.

Information collected is used to:
- Improve app performance
- Enhance user experience
- Fix bugs and crashes

We do not sell or share your personal data with third parties.

All data is stored securely and handled with care.
`;

  return (
    <InfoScreen
      title="Privacy Policy"
      content={content}
      navigation={navigation}
    />
  );
}