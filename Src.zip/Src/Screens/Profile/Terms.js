import React from 'react';
import InfoScreen from '../../Components/InfoScreen';

export default function TermsScreen({ navigation }) {
  const content = `
For a better experience, while using our Service, we may require you to provide certain personally identifiable information, including but not limited to name, email, phone number, and location.

The information that we request will be retained on your device and is not collected by us in any way.

The app may use third-party services that collect information used to identify you.

Log Data: Whenever you use our service, we collect data and information on your phone called Log Data. This may include your IP address, device name, OS version, app configuration, and usage statistics.

We use this information to improve our services, fix bugs, and enhance user experience.
`;

  return (
    <InfoScreen
      title="Terms & Conditions"
      content={content}
      navigation={navigation}
    />
  );
}