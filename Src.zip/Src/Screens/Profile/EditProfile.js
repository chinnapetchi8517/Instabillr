import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Modal,
  BackHandler,
} from 'react-native';
import fonts from '../../Utils/fonts';
import Icon from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from 'react-native-responsive-screen';
import colors from '../../Utils/colors';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function EditProfileScreen({ navigation }) {
  const [isEditing, setIsEditing] = useState(false);
  const [showModal, setShowModal] = useState(false);

  const [name, setName] = useState('Nusrat Jahan');
  const [email, setEmail] = useState('waiter@acnoo.com');
  const [phone, setPhone] = useState('01822334455');

  const handlePress = () => {
    console.log('Saved:', { name, email, phone });
    setIsEditing(true);
  };

  // 🔥 Android Back
  useEffect(() => {
    const backAction = () => {
      if (isEditing) {
        setShowModal(true);
        return true;
      }
      return false;
    };

    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      backAction
    );

    return () => backHandler.remove();
  }, [isEditing]);

  // 🔥 Navigation Back
  useEffect(() => {
    const unsubscribe = navigation?.addListener('beforeRemove', (e) => {
      if (!isEditing) return;

      e.preventDefault();
      setShowModal(true);
    });

    return unsubscribe;
  }, [navigation, isEditing]);

  const handleDiscard = () => {
    setShowModal(false);
    setIsEditing(false)
    navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.container}>

      {/* 🔶 HEADER */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setShowModal(true)}>
          <Icon name="arrow-back" size={wp('6%')} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{isEditing?"Edit Profile":"Profile"}</Text>
      </View>

      {/* 🔶 AVATAR */}
      <View style={styles.avatarContainer}>
        <View style={styles.avatar}>
          <Icon name="person" size={wp('10%')} color="#999" />
        </View>

        {/* Camera Icon */}
        {isEditing?
        <TouchableOpacity style={styles.cameraIcon}>
          <MaterialCommunityIcons name="image-edit" color="#fff" size={22} />
        </TouchableOpacity>
        :null}
      </View>

      {/* 🔶 FORM */}
      <View style={styles.content}>
        <Text style={styles.sectionTitle}>Profile Information</Text>

        <Text style={styles.label}>Full Name</Text>
        <TextInput editable={isEditing} style={styles.input} value={name} onChangeText={setName} />

        <Text style={styles.label}>Email</Text>
        <TextInput editable={isEditing}style={styles.input} value={email} onChangeText={setEmail} />

        <Text style={styles.label}>Phone Number</Text>
        <TextInput editable={isEditing} style={styles.input} value={phone} onChangeText={setPhone} />
      </View>

      {/* 🔶 BOTTOM BUTTON */}
      <View style={styles.bottomContainer}>
        <TouchableOpacity style={styles.button} onPress={()=>handlePress()}>
          <Icon name="create-outline" size={wp('5%')} color="#fff" />
          <Text style={styles.buttonText}> {isEditing?"Update":"Edit Profile"}</Text>
        </TouchableOpacity>
      </View>

      {/* 🔥 MODAL */}
      <Modal transparent visible={showModal} animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>

            {/* Warning Icon */}
            <View style={styles.warningCircle}>
              <Icon name="alert" size={wp('6%')} color="#fff" />
            </View>

            <Text style={styles.modalTitle}>
              Do you want to go back?
            </Text>

            <Text style={styles.modalText}>
              Fields that are changed may not be saved!
            </Text>

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.noButton}
                onPress={() => setShowModal(false)}
              >
                <Text style={{ color: colors.primary ,fontFamily:fonts.medium,}}>No</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.yesButton}
                onPress={()=>handleDiscard()}
              >
                <Text style={{ color: '#fff' ,fontFamily:fonts.medium,}}>Yes</Text>
              </TouchableOpacity>
            </View>

          </View>
        </View>
      </Modal>

    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f4f4',
  },

  header: {
    height: hp('8%'),
    backgroundColor: colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wp('4%'),
    gap: 10,
  },
  headerTitle: {
    color: '#fff',
    fontSize: wp('5%'),
    fontWeight: '600',
    fontFamily:fonts.bold,
  },

  avatarContainer: {
    alignItems: 'center',
    marginTop: hp('3%'),
  },
  avatar: {
    width: wp('25%'),
    height: wp('25%'),
    borderRadius: wp('12.5%'),
    borderWidth: 2,
    borderColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#eee',
  },
  cameraIcon: {
    position: 'absolute',
    bottom: 0,
    right: wp('34%'),
    backgroundColor:colors.primary,
    padding: 8,
    borderRadius: 20,
  },

  content: {
    paddingHorizontal: wp('5%'),
    marginTop: hp('3%'),
  },
  sectionTitle: {
    fontSize: wp('5%'),
    fontFamily:fonts.semiBold,
    marginBottom: hp('2%'),
  },
  label: {
    fontSize: wp('3.5%'),
    color: '#888',
    fontFamily:fonts.medium,
    marginTop: hp('1.5%'),
  },
  input: {
    height: hp('6%'),
    backgroundColor: '#eaeaea',
    borderRadius: wp('2%'),
    paddingHorizontal: wp('3%'),
    marginTop: hp('0.5%'),
    fontFamily:fonts.medium,
  },

  bottomContainer: {
    position: 'absolute',
    bottom: hp('3%'),
    width: '100%',
    paddingHorizontal: wp('5%'),
  },
  button: {
    flexDirection: 'row',
    height: hp('7%'),
    backgroundColor: colors.primary,
    borderRadius: wp('3%'),
    justifyContent: 'center',
    alignItems: 'center',
    gap: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: wp('4%'),
    fontFamily:fonts.bold,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '85%',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
  },

  warningCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },

  modalTitle: {
    fontSize: wp('5%'),
    fontFamily:fonts.bold,
    marginBottom: 10,

  },
  modalText: {
    fontSize: wp('3.5%'),
    textAlign: 'center',
    marginBottom: 20,
    fontFamily:fonts.medium,
    color: '#555',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 15,
  },
  noButton: {
    borderWidth: 1,
    borderColor: colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 25,
    borderRadius: 8,
  },
  yesButton: {
    backgroundColor: colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 25,
    borderRadius: 8,
  },
});