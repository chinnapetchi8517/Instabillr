import React, { useEffect, useState, useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker"; // or your date picker
import CustomDropdown from "../../Components/Dropdown";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

import colors from "../../Utils/colors";
import fonts from "../../Utils/fonts";
import { ApiService } from "../../Services/authService";
import { SafeAreaView } from "react-native-safe-area-context";

export default function ReportsScreen() {
    const [tables, setTables] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalOrderss, setTotalOrders] = useState(0);
  const [totalRevenues, setTotalRevenue] = useState(0);
const [showDatePicker, setShowDatePicker] = useState(false);

// Handler when date is selected
const onChangeDate = (event, date) => {
  setShowDatePicker(false); // hide picker
  if (date) setSelectedDate(date); // update selected date
};
  // Fetch table list
  const fetchTables = async () => {
    try {
      setLoading(true);
      const res = await ApiService.getTables();
      if (res.status) {
        const formatted = res.data.map((item) => ({
          id: item.id,
          name: item.name,
        }));
        setTables(formatted);
      }
    } catch (error) {
      console.log("❌ Table API Error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch report based on filters
  // After fetching data from API
const fetchReport = async () => {
  try {
    setLoading(true);
    let res = {};

    const dateStr = selectedDate.toISOString().split("T")[0]; // YYYY-MM-DD

    if (selectedTable && selectedDate) {
      res = await ApiService.getTableReportByDate(selectedTable.id, dateStr);
    } else if (selectedTable) {
      res = await ApiService.getTableReport(selectedTable.id);
    } else if (selectedDate) {
      res = await ApiService.getDailyReportByDate(dateStr);
    } else {
      res = await ApiService.getDailyReport();
    }

    if (res.status) {
      // Map API response to transactions array
      const mapped = (res.data?.data || []).map((item) => ({
        id: item.order_id,
        table: item.table_name,
        chair: item.chair_no,
        status: item.status,
        amount: item.order_total,
        orderTime: item.order_time,
        itemsCount: item.items_count,
      }));

      setTransactions(mapped);

      // ✅ Safely access summary
      const summary = res.data?.summary;
      setTotalOrders(summary?.total_orders || 0);
      setTotalRevenue(summary?.grand_total || 0);
    } else {
      setTransactions([]);
      setTotalOrders(0);
      setTotalRevenue(0);
    }
  } catch (error) {
    console.log("❌ Report API Error:", error);
    setTransactions([]);
    setTotalOrders(0);
    setTotalRevenue(0);
  } finally {
    setLoading(false);
  }
};
  useEffect(() => {
    fetchTables();
    fetchReport(); // show today's report on load
  }, []);

  // Re-fetch report when filters change
  useEffect(() => {
    fetchReport();
  }, [selectedDate, selectedTable]);

  // Totals
  const totalOrders = transactions.length;
  const totalRevenue = transactions.reduce((sum, t) => sum + t.amount, 0);
  const cashTotal = transactions
    .filter((t) => t.paymentType === "Cash")
    .reduce((sum, t) => sum + t.amount, 0);
  const cardTotal = transactions
    .filter((t) => t.paymentType === "Card")
    .reduce((sum, t) => sum + t.amount, 0);
  const upiTotal = transactions
    .filter((t) => t.paymentType === "UPI")
    .reduce((sum, t) => sum + t.amount, 0);

  const renderItem = ({ item }) => {
  return (
    <View style={styles.orderCard}>
      <Text style={styles.orderText}>
        {item.table} • Chair {item.chair} • ₹{item.amount}
      </Text>
      <Text style={styles.orderSub}>
        {item.status.toUpperCase()} • {item.orderTime} • Items: {item.itemsCount}
      </Text>
    </View>
  );
};

  return (
    <SafeAreaView style={{flex:1}}>
<View style={styles.header}>
        <Text style={styles.headerTitle}>Reports</Text>
      </View>
       <View style={styles.container}>
      {/* HEADER */}
      

      {/* FILTERS */}
      <View style={styles.filterContainer}>
        <TouchableOpacity   onPress={() => setShowDatePicker(true)}
 style={styles.datePicker} >
          {/* Implement your date picker modal */}
          <Text>{selectedDate.toDateString()}</Text>
        </TouchableOpacity>
{showDatePicker && (
  <DateTimePicker
    value={selectedDate}
    mode="date"
    display="default"
    onChange={onChangeDate}
  />
)}
        
      </View>
<CustomDropdown
label={'Select Table'}
selected={selectedTable}
          data={tables}
          onSelect={setSelectedTable}
        />
      {/* SUMMARY */}
      <View style={styles.summaryBox}>
        <Text style={styles.title}>Report Summary</Text>
        <Text style={styles.stat}>Orders: {totalOrders}</Text>
        <Text style={styles.stat}>Revenue: ₹{totalRevenue}</Text>
      </View>

      {/* PAYMENT BREAKDOWN */}
      <View style={styles.breakdownBox}>
        <Text style={styles.sectionTitle}>Payment Breakdown</Text>
        <Text style={styles.breakdown}>Cash: ₹{cashTotal}</Text>
        <Text style={styles.breakdown}>Card: ₹{cardTotal}</Text>
        <Text style={styles.breakdown}>UPI: ₹{upiTotal}</Text>
      </View>

      {/* ORDER LIST */}
      <View style={styles.listContainer}>
        <Text style={styles.sectionTitle}>Orders</Text>
        <FlatList
          data={transactions}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderItem}
          ListEmptyComponent={
            <Text style={styles.emptyText}>
              {loading ? "Loading..." : "No orders found"}
            </Text>
          }
        />
      </View>
    </View>
    </SafeAreaView>
   
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: wp("4%"), backgroundColor: "#f8f9fb" },
  header: { backgroundColor: colors.primary, padding: wp("4%") },
  headerTitle: { color: "#fff", fontSize: wp("5%"), fontFamily: fonts.semiBold },
  filterContainer: { flexDirection: "row", marginBottom: hp("2%") },
  datePicker: { borderWidth: 1, borderColor: "#ccc", borderRadius: 8, padding: wp("3%"),flex:1},
  summaryBox: { backgroundColor: "#fff", padding: wp("4%"),marginTop:20,borderRadius: 12, marginBottom: hp("2%"), elevation: 3 },
  breakdownBox: { backgroundColor: "#fff", padding: wp("4%"), borderRadius: 12, marginBottom: hp("2%"), elevation: 3 },
  sectionTitle: { fontSize: wp("4.5%"), fontFamily: fonts.bold, marginBottom: hp("1%") },
  breakdown: { fontSize: wp("4%"), fontFamily: fonts.medium, marginVertical: hp("0.5%") },
  listContainer: { flex: 1, backgroundColor: "#fff", borderRadius: 12, padding: wp("3%"), elevation: 3 },
  orderCard: { padding: wp("3%"), borderBottomWidth: 1, borderColor: "#eee" },
  orderText: { fontSize: wp("4%"), fontFamily: fonts.medium },
  orderSub: { fontSize: wp("3.5%"), color: "#777", marginTop: hp("0.3%") },
  emptyText: { textAlign: "center", marginTop: hp("2%"), color: "#999" },
  title: { fontSize: wp("5%"), fontFamily: fonts.bold, marginBottom: hp("1%") },
  stat: { fontSize: wp("4%"), fontFamily: fonts.medium, marginVertical: hp("0.3%") },
});