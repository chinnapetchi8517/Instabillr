import React,{useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { SafeAreaView } from 'react-native-safe-area-context';
import colors from '../../Utils/colors';
import fonts from '../../Utils/fonts';
const ProfileScreen = ({navigation}) => {
    const [showModal, setShowModal] = useState(false);
  
  const MenuItem = ({ icon, label, color }) => (
    <TouchableOpacity onPress={()=>Menuclick(label)} style={styles.menuItem}>
      <View style={[styles.iconBox, { backgroundColor: color + '20' }]}>
        <Icon name={icon} size={wp('6%')} color={color} />
      </View>
      <Text style={styles.menuText}>{label}</Text>
      <Icon name="chevron-right" size={wp('6%')} color="#999" />
    </TouchableOpacity>
  );

  const Menuclick=(label)=>{
if(label==='My Profile'){
  navigation.navigate('EditProfile')
}else if(label==='Terms & Conditions'){
  navigation.navigate('TermsScreen')

}else if(label==='Privacy Policy'){
  navigation.navigate('PrivacyScreen')

}else if(label==='About Us'){
  navigation.navigate('AboutScreen')

}if(label==='Logout'){
  setShowModal(true)

}
  }
  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Icon name="menu" size={wp('7%')} color="#fff" />
        <Text style={styles.headerText}>Profile</Text>
      </View>
 <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: hp('2%') }}
      >
      {/* Profile Info */}
      <View style={styles.profileSection}>
        <View style={styles.avatar}>
          <Icon name="account" size={wp('12%')} color="#ccc" />
        </View>
        <Text style={styles.name}>Nusrat Jahan</Text>
        <Text style={styles.role}>staff</Text>
      </View>

      {/* Menu */}
      <View style={styles.menuContainer}>
        <MenuItem icon="account-outline" label="My Profile" color="#4A90E2" />
        <MenuItem icon="translate" label="Language" color="#9B59B6" />
        <MenuItem icon="star-outline" label="Rate us" color="#E74C3C" />
        <MenuItem icon="file-document-outline" label="Terms & Conditions" color="#4A90E2" />
        <MenuItem icon="shield-alert-outline" label="Privacy Policy" color="#1ABC9C" />
        <MenuItem icon="information-outline" label="About Us" color="#9B59B6" />
        <MenuItem icon="logout" label="Logout" color="#7F8C8D" />
      </View>

    
     
      </ScrollView>
        <Modal transparent visible={showModal} animationType="fade">
              <View style={styles.modalOverlay}>
                <View style={styles.modalContainer}>
      
                  {/* Warning Icon */}
                  <View style={styles.warningCircle}>
                    <Icon name="alert" size={wp('6%')} color="#fff" />
                  </View>
      
                  <Text style={styles.modalTitle}>
                    Logout
                  </Text>
      
                  <Text style={styles.modalText}>
                    Are you sure to Logout?
                  </Text>
      
                  <View style={styles.modalButtons}>
                    <TouchableOpacity
                      style={styles.noButton}
                      onPress={() => setShowModal(false)}
                    >
                      <Text style={{ color: colors.primary,fontFamily:fonts.medium, }}>No</Text>
                    </TouchableOpacity>
      
                    <TouchableOpacity
                      style={styles.yesButton}
                      onPress={()=> {setShowModal(false),navigation.navigate('Login')}}
                    >
                      <Text style={{ color: '#fff' ,fontFamily:fonts.medium,}}>Logout</Text>
                    </TouchableOpacity>
                  </View>
      
                </View>
              </View>
            </Modal>
    </SafeAreaView>
  );
};

const TabItem = ({ icon, label, active }) => (
  <View style={styles.tabItem}>
    <Icon
      name={icon}
      size={wp('6%')}
      color={active ? '#FF7A00' : '#999'}
    />
    <Text style={[styles.tabText, active && { color: '#FF7A00' }]}>
      {label}
    </Text>
  </View>
);

export default ProfileScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f4f4',
  },

  header: {
    backgroundColor: colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    padding: wp('4%'),
  },

  headerText: {
    color: '#fff',
    fontSize: wp('5%'),
    marginLeft: wp('4%'),
   fontFamily:fonts.bold,
  },

  profileSection: {
    alignItems: 'center',
    paddingVertical: hp('3%'),
    backgroundColor: '#fff',
  },

  avatar: {
    width: wp('25%'),
    height: wp('25%'),
    borderRadius: wp('12.5%'),
    borderWidth: 2,
    borderColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },

  name: {
    fontSize: wp('5%'),
    fontWeight: '600',
    marginTop: hp('1.5%'),
    fontFamily:fonts.semiBold,
  },

  role: {
    color: '#888',
    fontSize: wp('4%'),
    fontFamily:fonts.medium,
  },

  menuContainer: {
    marginTop: hp('1%'),
  },

  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: wp('4%'),
    borderBottomWidth: 1,
    borderColor: '#eee',
  },

  iconBox: {
    width: wp('10%'),
    height: wp('10%'),
    borderRadius: wp('3%'),
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: wp('4%'),
  },

  menuText: {
    flex: 1,
    fontSize: wp('4%'),
    fontFamily:fonts.medium,
  },

  bottomTab: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: hp('1.5%'),
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderColor: '#eee',
  },

  tabItem: {
    alignItems: 'center',
  },

  tabText: {
    fontSize: wp('3%'),
    color: '#999',
    marginTop: 2,
  },
  modalOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0,0,0,0.5)',
      justifyContent: 'center',
      alignItems: 'center',
       width: '100%',
    },
    modalContainer: {
      width: '85%',
      backgroundColor: '#fff',
      borderRadius: 12,
      padding: 20,
      alignItems: 'center',
    },
  
    warningCircle: {
      width: 60,
      height: 60,
      borderRadius: 30,
      backgroundColor: colors.primary,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 10,
    },
  
    modalTitle: {
      fontSize: wp('5%'),
      fontFamily:fonts.bold,
      marginBottom: 10,
    },
    modalText: {
      fontSize: wp('3.5%'),
      textAlign: 'center',
      marginBottom: 20,
      fontFamily:fonts.medium,
      color: '#555',
    },
    modalButtons: {
      flexDirection: 'row',
      gap: 15,
    },
    noButton: {
      borderWidth: 1,
      borderColor: colors.primary,
      paddingVertical: 10,
      paddingHorizontal: 25,
      borderRadius: 8,
    },
    yesButton: {
      backgroundColor: colors.primary,
      paddingVertical: 10,
      paddingHorizontal: 25,
      borderRadius: 8,
    },
});