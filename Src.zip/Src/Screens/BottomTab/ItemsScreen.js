import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  Image,
  StatusBar,
} from "react-native";

import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

import { SafeAreaView } from "react-native-safe-area-context";
import Fonts from "../../Utils/fonts";
import colors from "../../Utils/colors";
import { ApiService } from "../../Services/authService";
import { useLoader } from "../../Context/LoaderContext";

const categories = ["All", "Veg", "Non-Veg", "Drinks"];

const ItemsScreen = ({ navigation, route }) => {
  const { onSelectProduct } = route.params || {};

  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const { showLoader, hideLoader } = useLoader();

  // =========================
  // 🔥 API CALL
  // =========================
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
            showLoader();

      const res = await ApiService.getProducts();

      if (res.status) {
        const formatted = res.data.map((item) => ({
          id: item.product_id.toString(),
          name: item.product_name,
          price: parseFloat(item.unit_price_inc_tax),
          category: "Non-Veg", // 🔥 TEMP (update when API gives category)
        }));

        setProducts(formatted);
      }
      hideLoader()
    } catch (err) {
      hideLoader()
      console.log("❌ Product API Error", err);
    }
  };

  // =========================
  // 🔍 FILTER
  // =========================
  const filteredData = products.filter((item) => {
    const matchSearch = item.name
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchCategory =
      selectedCategory === "All" ||
      item.category === selectedCategory;

    return matchSearch && matchCategory;
  });


const addItem = (item) => {
  const exists = cart.find((i) => i.id === item.id);

  if (exists) {
    setCart(
      cart.map((i) =>
        i.id === item.id ? { ...i, qty: i.qty + 1 } : i
      )
    );
  } else {
    setCart([...cart, { ...item, qty: 1 }]);
  }
};

const removeItem = (item) => {
  const exists = cart.find((i) => i.id === item.id);

  if (!exists) return;

  if (exists.qty === 1) {
    setCart(cart.filter((i) => i.id !== item.id));
  } else {
    setCart(
      cart.map((i) =>
        i.id === item.id ? { ...i, qty: i.qty - 1 } : i
      )
    );
  }
};
// Called when returning from ItemsScreen
// Merge incoming items into the current cart without duplicates
        console.log(route.params,"route.params");

const handleDone = async () => { 
  if (cart.length === 0) {
    alert("Please add at least one item");
    return;
  }

  try {
    // 🔹 Prepare payload
    const payload = {
      table_id: route.params?.tableId,
      chair_no: route.params?.chairs[0],
      order_type: route.params?.orderType.toLowerCase() || "family",
      items: cart.map((i) => ({
        product_id: parseInt(i.id),
        variation_id: i.variation_id || 1,
        qty: i.qty,
        unit_price_inc_tax: i.price,
      })),
    };

    // 🔹 Call API to create order
    const response = await ApiService.createOrder(payload);

    if (response.status) {
      console.log("Order Created:", response.data);

      const apiCart = response.data.items.map((i) => ({
  id: i.product_id || i.id || Math.random().toString(), // fallback
        name: i.product_name,
        qty: parseFloat(i.qty),
        price: parseFloat(i.unit_price_inc_tax),
        variation_id: i.variation_id,
      }));

      navigation.navigate("OrderScreen", {
        cart: apiCart,
        orderData: response.data,
        orderType: response.data.order_type,
        tableId: response.data.table_id,
        chairs: [response.data.chair_no],
      });

      if (onSelectProduct) onSelectProduct(apiCart);

    } else {
      // 🔹 Order already exists → call addItemsToOrder
      if (response.message === 'Order already open for this chair. Use add-items API to add more.') {

        // Ask backend for existing order ID
        const existingOrderId = route.params?.orderId;
        
        if (!existingOrderId) {
          alert("Cannot find existing order ID.");
          return;
        }

        // Call addItemsToOrder API
        const addItemsResponse = await ApiService.addItemsToOrder(existingOrderId, { items: payload.items });

        if (addItemsResponse.status) {
          console.log("Items added to existing order:", addItemsResponse.data);

          const apiCart = addItemsResponse.data?.items?.map((i) => ({
            id: i.product_id,
            name: i.product_name,
            qty: parseFloat(i.qty),
            price: parseFloat(i.unit_price_inc_tax),
            variation_id: i.variation_id,
          }));

          navigation.navigate("OrderScreen", {
            cart: apiCart,
            orderData: addItemsResponse.data,
            orderType: addItemsResponse.data.order_type,
            tableId: addItemsResponse.data.table_id,
            chairs: [addItemsResponse.data.chair_no],
          });

          if (onSelectProduct) onSelectProduct(apiCart);

        } else {
          alert(addItemsResponse.message || "Failed to add items");
        }

      } else {
        alert(response.message || "Failed to create order");
      }
    }
  } catch (error) {
    console.log("❌ Create/Add Items API Error:", error);
    alert("Failed to process order. Please try again.");
  }
};
const getQty = (id) => {
  const item = cart.find((i) => i.id === id);
  return item ? item.qty : 0;
};
  // =========================
  // 🧾 RENDER PRODUCT
  // =========================
 const renderItem = ({ item }) => {
  const qty = getQty(item.id); // 🔥 get quantity from cart

  return (
    <View style={styles.itemRow}>
      <Image
        source={require('../../../assets/Images/food.jpeg')}
        style={styles.image}
      />

      <View style={{ flex: 1 }}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.price}>₹{item.price}</Text>
      </View>

      {/* ✅ ADD / QTY BUTTON */}
      {qty === 0 ? (
        <TouchableOpacity
          style={styles.addBtn}
          onPress={() => addItem(item)}
        >
          <Text style={styles.addText}>ADD</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.qtyContainer}>
          <TouchableOpacity
            style={styles.qtyBtn}
            onPress={() => removeItem(item)}
          >
            <Text style={styles.qtyText}>-</Text>
          </TouchableOpacity>

          <Text style={styles.qtyNumber}>{qty}</Text>

          <TouchableOpacity
            style={styles.qtyBtn}
            onPress={() => addItem(item)}
          >
            <Text style={styles.qtyText}>+</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor={colors.primary} />

      {/* HEADER */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Select Items</Text>
      </View>

      {/* 🔍 SEARCH */}
      <View style={styles.searchBox}>
        <Icon name="magnify" size={wp("5%")} color="#777" />
        <TextInput
          placeholder="Search food..."
          value={search}
          onChangeText={setSearch}
          style={styles.input}
        />
      </View>

      {/* 🍱 CATEGORY */}
      {/* <View style={styles.categoryContainer}>
  {categories.map((item) => (
    <TouchableOpacity
      key={item}
      style={[
        styles.categoryBtn,
        selectedCategory === item && styles.activeCategory,
      ]}
      onPress={() => setSelectedCategory(item)}
    >
      <Text
        style={[
          styles.categoryText,
          selectedCategory === item && { color: "#fff" },
        ]}
      >
        {item}
      </Text>
    </TouchableOpacity>
  ))}
</View> */}

      {/* 🍽️ LIST */}
      <FlatList
        data={filteredData}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        showsVerticalScrollIndicator={false}
contentContainerStyle={{
    paddingTop: 5, // 👈 small clean spacing
    paddingBottom: hp("5%"),
  }}
      />
      {cart.length > 0 && (
  <View style={styles.footer}>
    <Text style={styles.itemCount}>
      {cart.length} Items Selected
    </Text>

    <TouchableOpacity style={styles.doneBtn} onPress={handleDone}>
      <Text style={styles.doneText}>DONE</Text>
    </TouchableOpacity>
  </View>
)}
    </SafeAreaView>
  );
};

export default ItemsScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
categoryContainer: {
  flexDirection: "row",
  paddingHorizontal: wp("3%"),
  marginBottom: hp("1%"),
},
  header: {
    backgroundColor: colors.primary,
    padding: wp("5%"),
  },

  headerTitle: {
    color: "#fff",
    fontSize: wp("5%"),
    fontFamily: Fonts.semiBold,
  },

  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    margin: wp("4%"),
    borderRadius: 10,
    paddingHorizontal: wp("3%"),
    height: hp("6%"),
  },

  input: {
    flex: 1,
    marginLeft: wp("2%"),
    fontFamily: Fonts.medium,
  },

  /* CATEGORY */
  categoryBtn: {
    paddingVertical: hp("1%"),
    paddingHorizontal: wp("4%"),
    backgroundColor: "#fff",
    borderRadius: 4,
    height:hp('5%'),
    padding:6,
    marginRight: wp("2%"),
    //marginBottom: hp("1%"),
  },

  activeCategory: {
    backgroundColor: colors.primary,
  },

  categoryText: {
    fontFamily: Fonts.medium,
    color: "#333",
  },

  /* ITEM */
  itemRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: wp("3%"),
    marginHorizontal: wp("3%"),
    marginBottom: hp("1%"),
    borderRadius: 10,
  },

  image: {
    width: wp("15%"),
    height: wp("15%"),
    borderRadius: wp("3%"),
    marginRight: wp("3%"),
  },

  name: {
    fontSize: wp("4%"),
    fontFamily: Fonts.semiBold,
  },

  price: {
    fontSize: wp("3.5%"),
    color: "#777",
    marginTop: 3,
  },

  addBtn: {
    backgroundColor: colors.primary,
    paddingHorizontal: wp("4%"),
    paddingVertical: hp("0.8%"),
    borderRadius: 6,
  },

  addText: {
    color: "#fff",
    fontFamily: Fonts.medium,
  },
  qtyContainer: {
  flexDirection: "row",
  alignItems: "center",
},

qtyBtn: {
  backgroundColor: colors.primary,
  paddingHorizontal: wp("3%"),
  paddingVertical: hp("0.5%"),
  borderRadius: 5,
},

qtyText: {
  color: "#fff",
  fontSize: wp("4%"),
  fontFamily: Fonts.bold,
},

qtyNumber: {
  marginHorizontal: wp("3%"),
  fontSize: wp("4%"),
  fontFamily: Fonts.bold,
},
footer: {
  position: "absolute",
  bottom: 0,
  width: "100%",
  backgroundColor: "#fff",
  padding: wp("4%"),
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: "center",
  borderTopWidth: 1,
  borderColor: "#eee",
},

itemCount: {
  fontFamily: Fonts.medium,
  fontSize: wp("4%"),
},

doneBtn: {
  backgroundColor: colors.primary,
  paddingVertical: hp("1.2%"),
  paddingHorizontal: wp("6%"),
  borderRadius: 8,
},

doneText: {
  color: "#fff",
  fontFamily: Fonts.bold,
  fontSize: wp("4%"),
},
});