import React, { useState, useEffect } from "react";
import {
View,
Text,
FlatList,
TouchableOpacity,
TextInput,
Image,
ActivityIndicator,
StyleSheet,
StatusBar
} from "react-native";
import fonts from "../../Utils/fonts";
import { Picker } from "@react-native-picker/picker";
import Icon from "react-native-vector-icons/Feather";
import {
widthPercentageToDP as wp,
heightPercentageToDP as hp
} from "react-native-responsive-screen";
import Header from "../../Components/Header";
import { useNavigation } from "@react-navigation/native";
import CustomDropdown from "../../Components/Dropdown";
import { SafeAreaView } from "react-native-safe-area-context";
import colors from "../../Utils/colors";
import FilterModal from "../../Components/FilterModal";
const tableData = [
{ id:"1", name:"Table 1", status:"Running" },
{ id:"2", name:"Table 2", status:"Running" },
{ id:"3", name:"Table 3", status:"Running" },
{ id:"4", name:"Table 4", status:"Running" },
{ id:"5", name:"Table 5", status:"Running" }
];

const waiterData = [
{ id:"1", name:"Nusrat Jahan" }
];
const orderTypes = ["Dine In", "Pick Up", "Delivery","Reservation","Quatation"];

export default function SalesScreen() {

const [selectedType, setSelectedType] = useState("Dine In");


const [customer, setCustomer] = useState("");

const [search, setSearch] = useState("");

const [items, setItems] = useState([]);
const [page, setPage] = useState(1);

const [loading, setLoading] = useState(false);
const [loadingMore, setLoadingMore] = useState(false);
const [hasMore, setHasMore] = useState(true);

const [table,setTable] = useState(null);
const [waiter,setWaiter] = useState(null);

const [showFilter, setShowFilter] = useState(false);

const navigation= useNavigation()
const formatData = (data, numColumns) => {
  const fullRows = Math.floor(data.length / numColumns);
  let lastRowItems = data.length - fullRows * numColumns;

  while (lastRowItems !== 0 && lastRowItems !== numColumns) {
    data.push({ id: `empty-${lastRowItems}`, empty: true });
    lastRowItems++;
  }

  return data;
};
// Fake API call
const fetchItems = async (pageNumber = 1) => {

if (pageNumber === 1) setLoading(true);
else setLoadingMore(true);

setTimeout(() => {

let newItems = Array.from({ length: 11 }).map((_, i) => ({
id: pageNumber + "-" + i,
name: "Item " + (pageNumber * 10 + i),
price: 200,
image: "https://picsum.photos/200"
}));

if (pageNumber === 1)
setItems(newItems);
else
setItems(prev => [...prev, ...newItems]);

setHasMore(pageNumber < 5);

setLoading(false);
setLoadingMore(false);

}, 1200);

};


useEffect(() => {
fetchItems(1);
}, []);



const loadMore = () => {
if (!hasMore || loadingMore) return;

const next = page + 1;
setPage(next);
fetchItems(next);
};


const renderItem = ({ item }) => (

<View style={styles.card}>

<Image
source={{ uri: item.image }}
style={styles.image}
/>

<Text style={styles.itemName}>{item.name}</Text>

<Text style={styles.price}>$ {item.price}</Text>

</View>

);


return (
<SafeAreaView style={{ flex:1,backgroundColor:'white'}}>
    <StatusBar backgroundColor={colors.primary}></StatusBar>
<Header
title="Sam Restaurant"
notificationCount={3}
isnotify={true}
onMenuPress={() => navigation.openDrawer()}
onNotificationPress={() => console.log("Notification clicked")}
/>

<View style={styles.container}>


{/* Horizontal Order Type */}

<View style={styles.orderRow}>

  <FlatList
    data={orderTypes}
    horizontal
    showsHorizontalScrollIndicator={false}
    keyExtractor={(item) => item}
    contentContainerStyle={{
      paddingLeft: wp("1%"),
      alignItems: "center"
    }}
    renderItem={({ item }) => (

      <TouchableOpacity
        style={[
          styles.orderBtn,
          selectedType === item && styles.orderBtnActive
        ]}
        onPress={() => setSelectedType(item)}
      >

        <Text
          style={[
            styles.orderText,
            selectedType === item && styles.orderTextActive
          ]}
        >
          {item}
        </Text>

      </TouchableOpacity>

    )}
  />

</View>


{/* Dropdown Row */}

<View style={{ flexDirection:'row',justifyContent:'space-between',gap:10}}>

<CustomDropdown
dropstyle={{width:wp('45%')}}
label="Select Waiter"
data={waiterData}
selected={waiter}
onSelect={setWaiter}
onAddNew={()=>console.log("Add waiter")}
/>

<CustomDropdown
label="Select Table"
data={tableData}
selected={table}
dropstyle={{width:wp('45%')}}
onSelect={setTable}
showStatus
onAddNew={()=>console.log("Add table")}
/>

</View>

<View style={styles.customerRow}>

  <View style={{ flex: 1 }}>
    <CustomDropdown
      label="Select Customer"
      data={tableData}
      selected={customer}
      onSelect={setCustomer}
    />
  </View>

  <TouchableOpacity
    style={styles.addBtn}
    onPress={() => console.log("Add Customer")}
  >
    <Icon name="plus" size={20} color="#000" />
  </TouchableOpacity>

</View>


{/* Search Bar */}

<View style={styles.searchBox}>

  <Icon name="search" size={18} color="#777" />

  <TextInput
    placeholder="Search Items Name"
    value={search}
    onChangeText={setSearch}
    style={styles.input}
  />


  <TouchableOpacity  onPress={() => {
  console.log("Filter Clicked"); // 👈 check this prints
  setShowFilter(true);
}} style={styles.filterBtn}>
    <Icon name="sliders" size={18} color={colors.primary} />
  </TouchableOpacity>

</View>


{/* Loader */}

{loading ? (

<ActivityIndicator size="large" color={colors.primary} />

) : (

<FlatList
data={formatData(items, 3)}
  numColumns={3}
renderItem={renderItem}
keyExtractor={(item) => item.id}
onEndReached={loadMore}
onEndReachedThreshold={0.4}
contentContainerStyle={{ paddingBottom: hp("12%") }}
ListFooterComponent={
loadingMore ?
<ActivityIndicator size="small" color="orange" />
: null
}

ListEmptyComponent={
<View style={{ alignItems: "center", marginTop: 50 }}>
<Text>No Data Found</Text>
</View>
}

/>

)}
<View style={styles.bottomBar}>

  <TouchableOpacity style={styles.smallBtn}>
    <Text style={styles.smallText}>Kitchen</Text>
  </TouchableOpacity>

  <TouchableOpacity style={styles.smallBtn}>
    <Text style={styles.smallText}>KOT</Text>
  </TouchableOpacity>

  <View style={styles.qtyBox}>
    <Text style={styles.qtyText}>1</Text>
  </View>

  <TouchableOpacity style={styles.payBtn}>
    <Text style={styles.payText}>Pay $370</Text>
  </TouchableOpacity>

</View>

<FilterModal
  visible={showFilter}
  onClose={() => setShowFilter(false)}
/>
</View>

</SafeAreaView>
);

}

const styles = StyleSheet.create({
customerRow:{
  flexDirection:"row",
  alignItems:"center",
  gap:10,
  marginVertical:hp("1%")
},

addBtn:{
  width:wp("12%"),
  height:wp("12%"),
  borderWidth:1,
  borderColor:"#ddd",
  borderRadius:wp("2%"),
  alignItems:"center",
  justifyContent:"center",
  backgroundColor:"#f5f5f5"
},

filterBtn:{
  backgroundColor:"#f3eafd",
  padding:wp("2%"),
  borderRadius:wp("2%")
},

bottomBar:{
  position:"absolute",
  bottom:0,
  left:0,
  right:0,
  flexDirection:"row",
  alignItems:"center",
  padding:wp("3%"),
  backgroundColor:"#fff",
  borderTopWidth:1,
  borderColor:"#eee"
},

smallBtn:{
  borderWidth:1,
  borderColor:colors.primary,
  paddingVertical:hp("1%"),
  paddingHorizontal:wp("3%"),
  borderRadius:wp("2%"),
  marginRight:wp("2%")
},

smallText:{
  color:colors.primary,
  fontWeight:"600",
  fontFamily:fonts.medium,
},

qtyBox:{
  backgroundColor:colors.primary,
  paddingHorizontal:wp("4%"),
  paddingVertical:hp("1%"),
  borderRadius:wp("2%"),
  marginRight:wp("2%")
},

qtyText:{
fontFamily:fonts.bold,
},

payBtn:{
  flex:1,
  backgroundColor:colors.primary,
  paddingVertical:hp("1.5%"),
  borderRadius:wp("2%"),
  alignItems:"center"
},

payText:{
  color:"#fff",
  fontSize:wp("4%"),
  fontFamily:fonts.bold,
},
container:{
flex:1,
padding:wp("3%"),
backgroundColor:"#fff"
},

orderRow:{
flexDirection:"row",
marginBottom:hp("1.5%")
},

orderBtn:{
borderWidth:1,
borderColor:"#ddd",
paddingVertical:hp("1%"),
paddingHorizontal:wp("4%"),
borderRadius:wp("2%"),
marginRight:wp("2%")
},

orderBtnActive:{
borderColor:colors.primary,
backgroundColor: "#f3eafd",
},

orderText:{
color:"#777",
fontWeight:'600',
fontSize:wp("3.5%"),
fontFamily:fonts.medium,
},

orderTextActive:{
color:colors.primary
},

dropdownRow:{
flexDirection:"row",
justifyContent:"space-between"
},

dropdown:{
flex:1,
borderWidth:1,
borderColor:"#ddd",
borderRadius:wp("2%"),
marginVertical:hp("0.7%"),
marginRight:wp("1%")
},

searchBox:{
flexDirection:"row",
alignItems:"center",
borderWidth:1,
borderColor:"#ddd",
borderRadius:wp("2%"),
paddingHorizontal:wp("3%"),
marginVertical:hp("1%")
},

input:{
flex:1,
padding:hp("1.8%"),
fontSize:wp("3.5%"),
fontFamily:fonts.medium,
},

card:{
flex:1,
backgroundColor:"#fff",
margin:wp("1.5%"),
padding:hp("1%"),
borderRadius:wp("3%"),
alignItems:"center",
elevation:3
},

image:{
width:wp("18%"),
height:wp("18%"),
resizeMode:"cover"
},

itemName:{
marginTop:hp("0.7%"),
fontWeight:"600",
fontFamily:fonts.medium,
fontSize:wp("3.5%"),
textAlign:"center"
},

price:{
color:"#777",
fontSize:wp("3.3%"),
fontFamily:fonts.regular,
}

});